package processing.oculus;

public interface Oculus {
	static final String RENDERER = "processing.oculus.POculusRenderer";  
}