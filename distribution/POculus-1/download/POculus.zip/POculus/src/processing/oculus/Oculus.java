package processing.oculus;

public interface Oculus {
	static final String P3D    = "processing.oculus.PGraphics3D";  
}
